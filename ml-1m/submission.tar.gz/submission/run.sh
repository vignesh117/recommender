python expm_clustering.py > recommendations
python evaluate.py > final_results
